// Creates backend/.env from the example (with a random JWT secret) if it does not exist yet.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const dir = path.join(__dirname, '..', 'backend');
const env = path.join(dir, '.env');
if (fs.existsSync(env)) {
  console.log('[init] backend/.env already exists, leaving it alone');
} else {
  let text = fs.readFileSync(path.join(dir, '.env.example'), 'utf8');
  text = text.replace(/^JWT_SECRET=.*$/m, `JWT_SECRET=${crypto.randomBytes(32).toString('hex')}`);
  fs.writeFileSync(env, text);
  console.log('[init] created backend/.env  ->  now add GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET (and DATABASE_URL / REDIS_URL if not using Docker)');
}
