// Starts the API (+ worker) and the frontend together WITHOUT a shell (no cmd.exe / sh needed),
// so it works even when the terminal's PATH is unusual.
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const targets = [
  { name: 'api', color: '\x1b[34m', cwd: 'backend', script: ['node_modules', 'tsx', 'dist', 'cli.mjs'], args: ['watch', 'src/index.ts'] },
  { name: 'web', color: '\x1b[32m', cwd: 'frontend', script: ['node_modules', 'vite', 'bin', 'vite.js'], args: [] },
];

for (const t of targets) {
  const file = path.join(root, t.cwd, ...t.script);
  if (!fs.existsSync(file)) {
    console.error(`[dev] ${t.cwd} dependencies are missing (${file}). Run "npm install" in the project root first.`);
    process.exit(1);
  }
  t.file = file;
}

const children = [];
let stopping = false;
const stopAll = (code) => {
  if (stopping) return;
  stopping = true;
  children.forEach((c) => c.kill());
  setTimeout(() => process.exit(code), 300);
};

for (const t of targets) {
  const child = spawn(process.execPath, [t.file, ...t.args], { cwd: path.join(root, t.cwd), env: process.env });
  children.push(child);
  const prefix = `${t.color}[${t.name}]\x1b[0m `;
  const pipe = (stream, out) => {
    let buf = '';
    stream.on('data', (d) => {
      buf += d.toString();
      const lines = buf.split(/\r?\n/);
      buf = lines.pop();
      lines.forEach((l) => l && out.write(prefix + l + '\n'));
    });
  };
  pipe(child.stdout, process.stdout);
  pipe(child.stderr, process.stderr);
  child.on('error', (e) => {
    console.error(`${prefix}failed to start: ${e.message}`);
    stopAll(1);
  });
  child.on('exit', (code) => {
    console.log(`${prefix}exited with code ${code}`);
    stopAll(code ?? 0);
  });
}
process.on('SIGINT', () => stopAll(0));
process.on('SIGTERM', () => stopAll(0));
