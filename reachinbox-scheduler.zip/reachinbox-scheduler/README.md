# ReachInbox Email Scheduler

Full-stack email job scheduler: **Express + TypeScript**, **BullMQ + Redis** delayed jobs (no cron), **PostgreSQL**, **Ethereal SMTP** (multiple senders), **Elasticsearch** search, live **Bull Board** dashboard, **Slack OAuth** alerts, and a **React + Tailwind** dashboard with **Google login**.

## Run it: step by step

Prerequisites: Node 20+. You also need Postgres and Redis (step 2).

**1. Install everything** (root, backend and frontend; also creates `backend/.env` with a random `JWT_SECRET`)
```bash
npm install
```

**2. Get Postgres and Redis**: pick one.
- **A. Docker:** `docker compose up -d` (Postgres, Redis with persistence, Elasticsearch). Defaults in `.env` already match.
- **B. No Docker, no installs:** create a free database on Neon (or Supabase) and a free Redis on Upstash. In `backend/.env` set `DATABASE_URL=<neon connection string>` and `REDIS_URL=<rediss://... from Upstash>`.
- **C. Windows with WSL2:** `sudo apt install postgresql redis-server`, create a database named `scheduler`, keep the default URLs.

Elasticsearch is optional: without it, search falls back to SQL and everything else works.

**3. Add Google credentials** to `backend/.env`
Google Cloud Console > APIs & Services > Credentials > Create OAuth client ID (Web application). Authorized redirect URI: `http://localhost:4000/api/auth/google/callback`. Add your Google account as a test user on the consent screen. Copy the client ID/secret into `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`.

**4. Check your setup**
```bash
npm run doctor
```
It tests config, Postgres, Redis and Elasticsearch and prints the exact fix for anything missing.

**5. Start everything** (API + worker on :4000, frontend on :5173)
```bash
npm run dev
```
Prefer two terminals (or `npm run dev` misbehaves)? Run `npm run dev:api` in one and `npm run dev:web` in the other.
Open **http://localhost:5173** in Chrome (use `localhost`, not a 192.168.x.x address, and not an embedded editor browser: Google rejects both). Sign in, click **Compose new email**, upload `sample-leads.csv`.

**6. Optional: Slack alerts.** api.slack.com/apps > Create app > OAuth & Permissions: add redirect URL `http://localhost:4000/api/slack/callback` and scope `incoming-webhook`, then enable Incoming Webhooks. Put `SLACK_CLIENT_ID/SECRET` in `backend/.env`, restart, click **Connect Slack** in the dashboard, then **Send test**. If Slack rejects localhost, use a tunnel (ngrok) and set `BACKEND_URL` to it.

**Ethereal:** nothing to set up. On first boot the backend creates `SENDER_COUNT` (default 3) Ethereal accounts and stores them in the `senders` table. Every sent email gets a **Preview** link in the Sent tab. To use your own accounts, set `ETHEREAL_ACCOUNTS=[{"user":"..","pass":".."}]`.

**Testing without Google:** set `DEV_LOGIN=true` in `backend/.env` to get a "Dev login" button (local only, never in production).

### Environment variables (`backend/.env`)

| Variable | Purpose | Default |
|---|---|---|
| `GOOGLE_CLIENT_ID/SECRET` | Google OAuth | required |
| `SLACK_CLIENT_ID/SECRET` | Slack OAuth | required for Slack |
| `DATABASE_URL`, `REDIS_URL`, `ELASTICSEARCH_URL` | Infra | local Docker |
| `SENDER_COUNT` | Ethereal senders to create | `3` |
| `WORKER_CONCURRENCY` | Parallel jobs per worker | `5` |
| `MIN_DELAY_BETWEEN_EMAILS_MS` | Minimum gap between any two sends | `2000` |
| `MAX_EMAILS_PER_HOUR_PER_SENDER` | Hourly cap per sender | `100` |
| `ROLE` | `all`, `api` or `worker` (scale them separately) | `all` |
| `DEV_LOGIN` | Local-only dev login | unset |

## Architecture

```
React (Vite, proxied) --> Express API --> Postgres  (source of truth)
                             |  \--------> Elasticsearch (search index)
                             v
                      BullMQ queue (Redis) --> Worker(s) --> Ethereal SMTP
                                                  |
                                                  +--> Redis rate counters --> Slack webhook
```

### Scheduling
`POST /api/emails/schedule` takes subject, body, recipients, start time, delay and hourly limit. The service plans a send time for every recipient, inserts the rows in Postgres, then adds one **BullMQ delayed job** per email with `delay = sendTime - now`. No cron anywhere: Redis holds the delayed jobs and BullMQ promotes them when due.

### Persistence on restart
Delayed jobs live in Redis (AOF persistence in `docker-compose.yml`) and every email is also a Postgres row. After a restart the worker resumes and due jobs fire at the correct time. On boot, `reconcile()` re-adds a job for each row still `scheduled` (or stuck `processing` for 5+ minutes). Job id equals email id, so BullMQ ignores ids that already exist: it can repair gaps but never duplicate.

### Idempotency
1. `jobId = emailId`: one job per email.
2. The worker claims the row atomically (`UPDATE ... WHERE status='scheduled'`); a replay or second worker gets 0 rows and exits.
3. Deterministic `Message-ID` header.

### Concurrency, delay and rate limiting
- **Concurrency:** `WORKER_CONCURRENCY` per worker process; safe because of the atomic claim.
- **Minimum delay between sends:** BullMQ `limiter { max: 1, duration: MIN_DELAY_BETWEEN_EMAILS_MS }`, default **2 seconds between any two sends**, enforced in Redis across all workers.
- **Emails per hour (per sender):** effective limit = `min(hourly limit from the compose form, MAX_EMAILS_PER_HOUR_PER_SENDER)`.
  - *At schedule time*, each email is slotted into the earliest hour window with free quota (counting rows from earlier batches), on the sender that can send it soonest. Order is preserved and the user's delay is kept inside each window. 1000+ emails due at once are therefore spread over upcoming windows immediately, with nothing dropped and no queue churn.
  - *At send time*, the worker takes a slot from an atomic Redis Lua counter keyed `rl:{sender}:{hourWindow}` (safe across workers and instances). If it is somehow over the limit (other batches, drift), the job is moved to the next window with `moveToDelayed`, never failed. Failed sends release their slot.
- **Slack alert:** when a send uses a sender's last slot in a window, the worker posts to the user's Slack (once per sender per window).

### Behaviour under load
Run `npm run loadtest -- 1000 5` while `npm run dev` is running: it schedules 1000 emails for the same instant (5 per sender per hour) and prints how they were spread across hour windows. Watch the dashboard (queue panel and sender usage bars) and Bull Board.

### Slack
"Connect Slack" runs the real OAuth v2 flow and stores the incoming webhook per user. Not connected means silently skipped; connect later and alerts start immediately, no redeploy. A revoked webhook (404/410) is cleaned up automatically.

### Search and queue dashboard
Elasticsearch index `emails` is updated on schedule and every status change; `GET /api/emails?status=sent&q=term` does fuzzy multi-field search (SQL fallback if Elasticsearch is down). Bull Board: http://localhost:4000/admin/queues (sign in first; linked in the header).

## Features implemented

| Area | Feature |
|---|---|
| Backend | Schedule API, Postgres, BullMQ delayed jobs (no cron), multiple Ethereal senders |
| Backend | Restart-safe persistence, boot reconciliation, idempotent sends |
| Backend | Configurable concurrency, min delay, per-sender hourly limit (planned at schedule time + enforced in Redis), next-window rescheduling |
| Backend | Slack OAuth + live alert, Elasticsearch indexing/search, Bull Board, stats API, load-test script, `doctor` check |
| Frontend | Google login, header with name/email/avatar, logout |
| Frontend | Scheduled / Sent tabs with counts, loading, empty and error states, live refresh, search |
| Frontend | Compose modal: subject, body, CSV/text upload with detected-email count, start time, delay, hourly limit |
| Frontend | Live stats panel (queue, per-sender usage, worker settings), Slack connect/test/disconnect |
| Frontend | Reusable UI kit (Button, Field, Modal, Badge, Toast, DataTable), typed API layer and hooks |

## API

| Method | Path | Notes |
|---|---|---|
| GET | `/api/auth/google`, `/api/auth/google/callback` | OAuth login |
| GET | `/api/auth/me`, POST `/api/auth/logout` | session |
| POST | `/api/emails/schedule` | `{subject, body, recipients[], startTime?, delaySeconds, hourlyLimit?}` |
| GET | `/api/emails?status=scheduled\|sent&q=&limit=&offset=` | list / search |
| GET | `/api/stats` | queue counts, sender usage, worker settings |
| GET | `/api/slack/install`, `/callback`, `/status`; POST `/test`; DELETE `/api/slack` | Slack |

## Demo script (5 min)
1. Log in; connect Slack; **Send test**.
2. Compose with `sample-leads.csv`, delay 1 s, hourly limit 2: part sends now, the rest shows next-hour times; show the Slack alert and the usage bars.
3. **Restart:** schedule 3 emails 1-2 minutes ahead, stop the backend (the UI shows an error), start it again: they still send on time, once.
4. `npm run loadtest -- 1000 5`: show Delayed jump in the stats panel and the spread of times; open Bull Board.

## Assumptions, shortcuts and trade-offs
- Fixed hourly windows (simple and atomic), not sliding: a burst is possible across a window boundary.
- Exactly-once is approximated: a crash between SMTP acceptance and the DB update could resend (stale-claim window 5 minutes). Harmless with Ethereal; a real provider needs idempotency keys.
- `reconcile()` runs once at boot, not periodically (that would be cron-like).
- Sender accounts are shared across users; per-user senders would be a small schema change.
- The UI follows a clean layout of my own; adjust colours and spacing to match your Figma file.
- Verified manually end to end against local Postgres and Redis (hourly limit and Slack alert, 1000-email load test, kill and restart, no duplicate sends). Google, Slack and Ethereal were exercised through local stand-ins, so run those once on your machine.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `HTTP ERROR 500/502` on `/api/...` | Backend is not running. Run `npm run doctor`, then `npm run dev` and read the backend terminal (`[startup] Cannot reach PostgreSQL/Redis`). The login page also shows the reason. |
| `spawn cmd.exe ENOENT` (Windows) | Fixed: `npm run dev` now uses a shell-free launcher. If you still see it, use `npm run dev:api` and `npm run dev:web` in two terminals, and open a normal PowerShell or Command Prompt. |
| Blank page at `/api/auth/google` | Same as above, or you opened it in an embedded browser. Use Chrome at http://localhost:5173. |
| `redirect_uri_mismatch` | Redirect URI in Google Cloud must be exactly `http://localhost:4000/api/auth/google/callback`. |
| "Google sign-in is not configured" | Add the Google keys to `backend/.env` and restart. |
| Emails stay `scheduled` | Worker not running (`ROLE=api`) or Redis unreachable. |
| `No sender accounts available yet` | Ethereal unreachable on first boot (needs internet). Restart, or set `ETHEREAL_ACCOUNTS`. |
