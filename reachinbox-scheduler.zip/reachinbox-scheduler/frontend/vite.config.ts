import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// If the backend is down, answer with a readable 502 instead of an empty HTTP 500.
const proxyTo = (target: string) => ({
  target,
  configure: (proxy: any) => {
    proxy.on('error', (_err: Error, _req: unknown, res: any) => {
      if (res && !res.headersSent) res.writeHead(502, { 'Content-Type': 'application/json' });
      res?.end?.(
        JSON.stringify({
          error: `Backend is not running on ${target}. Start it with "npm run dev" and check its terminal (or run "npm run doctor").`,
        }),
      );
    });
  },
});

// The dev server proxies the API so cookies stay same-origin (no CORS setup needed).
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5173,
    proxy: {
      '/api': proxyTo('http://127.0.0.1:4000'),
      '/admin': proxyTo('http://127.0.0.1:4000'),
    },
  },
});
