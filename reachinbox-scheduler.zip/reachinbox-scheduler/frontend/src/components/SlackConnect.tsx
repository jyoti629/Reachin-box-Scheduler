import { useEffect, useState } from 'react';
import { api } from '../api';
import type { SlackStatus } from '../types';
import { Button } from './ui/Button';
import { useToast } from './ui/Toast';

export function SlackConnect() {
  const toast = useToast();
  const [status, setStatus] = useState<SlackStatus | null>(null);

  const refresh = () => api.slackStatus().then(setStatus).catch(() => setStatus(null));

  useEffect(() => {
    refresh();
    const flag = new URLSearchParams(window.location.search).get('slack');
    if (flag) {
      if (flag === 'connected') toast('success', 'Slack connected. Rate-limit alerts will post there.');
      else toast('error', 'Slack connection failed. Check the Slack app settings and try again.');
      window.history.replaceState({}, '', '/');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!status) return null;

  if (!status.connected) {
    return (
      <Button variant="secondary" onClick={() => (window.location.href = '/api/slack/install')}>
        Connect Slack
      </Button>
    );
  }

  return (
    <div className="flex items-center gap-1 text-sm">
      <span className="font-medium text-ok">Slack {status.channel ?? 'connected'}</span>
      <Button
        variant="ghost"
        onClick={async () => {
          const r = await api.slackTest().catch(() => ({ ok: false }));
          toast(r.ok ? 'success' : 'error', r.ok ? 'Test message sent to Slack.' : 'Could not reach Slack.');
        }}
      >
        Send test
      </Button>
      <Button
        variant="ghost"
        onClick={async () => {
          await api.slackDisconnect();
          toast('success', 'Slack disconnected.');
          refresh();
        }}
      >
        Disconnect
      </Button>
    </div>
  );
}
