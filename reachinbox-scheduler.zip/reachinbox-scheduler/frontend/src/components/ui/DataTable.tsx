import { ReactNode } from 'react';

export interface Column<T> {
  header: string;
  render: (row: T) => ReactNode;
  className?: string;
}

interface Props<T> {
  columns: Column<T>[];
  rows: T[];
  rowKey: (row: T) => string;
  loading: boolean;
  error?: string | null;
  empty: { title: string; hint: string };
}

/** Generic table with loading, error and empty states built in. */
export function DataTable<T>({ columns, rows, rowKey, loading, error, empty }: Props<T>) {
  if (loading) {
    return (
      <div className="flex items-center justify-center gap-3 py-20 text-sm text-muted" role="status">
        <span className="h-5 w-5 animate-spin rounded-full border-2 border-brand border-t-transparent" />
        Loading emails…
      </div>
    );
  }
  if (error) {
    return <div className="py-16 text-center text-sm text-bad">Could not load emails: {error}</div>;
  }
  if (!rows.length) {
    return (
      <div className="py-20 text-center">
        <p className="font-semibold">{empty.title}</p>
        <p className="mt-1 text-sm text-muted">{empty.hint}</p>
      </div>
    );
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-line text-muted">
            {columns.map((c) => (
              <th key={c.header} className={`px-4 py-3 font-medium ${c.className ?? ''}`}>
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={rowKey(row)} className="border-b border-line/60 last:border-0 hover:bg-canvas/60">
              {columns.map((c) => (
                <td key={c.header} className={`px-4 py-3 ${c.className ?? ''}`}>
                  {c.render(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
