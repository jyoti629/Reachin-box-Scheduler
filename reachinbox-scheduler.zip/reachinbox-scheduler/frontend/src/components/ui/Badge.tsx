import type { EmailStatus } from '../../types';

const styles: Record<EmailStatus, string> = {
  scheduled: 'bg-brand/10 text-brand-dark',
  processing: 'bg-warn/15 text-warn',
  sent: 'bg-ok/10 text-ok',
  failed: 'bg-bad/10 text-bad',
};

export function StatusBadge({ status }: { status: EmailStatus }) {
  return (
    <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize ${styles[status]}`}>
      {status}
    </span>
  );
}
