import { useEffect, useState } from 'react';
import { api } from '../api';
import type { Stats } from '../types';

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-line bg-white p-4 shadow-sm">
      <h3 className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted">{title}</h3>
      {children}
    </div>
  );
}

function Num({ label, value, tone = '' }: { label: string; value: number; tone?: string }) {
  return (
    <div>
      <div className={`text-2xl font-bold tabular-nums ${tone}`}>{value}</div>
      <div className="text-xs text-muted">{label}</div>
    </div>
  );
}

/** Live queue + rate-limit view; makes the hourly limit and throttling visible. */
export function StatsBar() {
  const [s, setS] = useState<Stats | null>(null);

  useEffect(() => {
    let alive = true;
    const load = () => api.stats().then((x) => alive && setS(x)).catch(() => {});
    load();
    const t = setInterval(load, 3000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  if (!s) return null;
  const resets = new Date(s.windowEndsAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="mb-5 grid gap-3 md:grid-cols-3">
      <Card title="Queue (BullMQ)">
        <div className="grid grid-cols-4 gap-2">
          <Num label="Waiting" value={s.queue.waiting} />
          <Num label="Delayed" value={s.queue.delayed} tone="text-brand" />
          <Num label="Active" value={s.queue.active} tone="text-warn" />
          <Num label="Failed" value={s.queue.failed} tone={s.queue.failed ? 'text-bad' : ''} />
        </div>
      </Card>
      <Card title={`Sender usage this hour (resets ${resets})`}>
        <ul className="space-y-2">
          {s.senders.map((x) => {
            const pct = Math.min(100, (x.usedThisHour / x.limit) * 100);
            return (
              <li key={x.id} className="text-xs">
                <div className="mb-1 flex justify-between">
                  <span className="max-w-40 truncate">{x.email}</span>
                  <span className="tabular-nums text-muted">
                    {x.usedThisHour} / {x.limit}
                  </span>
                </div>
                <div className="h-1.5 rounded bg-canvas">
                  <div className={`h-1.5 rounded ${pct >= 100 ? 'bg-bad' : 'bg-brand'}`} style={{ width: `${pct}%` }} />
                </div>
              </li>
            );
          })}
        </ul>
      </Card>
      <Card title="Worker settings">
        <dl className="space-y-1 text-sm">
          <div className="flex justify-between"><dt className="text-muted">Concurrency</dt><dd className="font-semibold">{s.worker.concurrency}</dd></div>
          <div className="flex justify-between"><dt className="text-muted">Min delay between sends</dt><dd className="font-semibold">{s.worker.minDelayMs} ms</dd></div>
          <div className="flex justify-between"><dt className="text-muted">Hourly limit / sender</dt><dd className="font-semibold">{s.senders[0]?.limit ?? '-'}</dd></div>
        </dl>
      </Card>
    </div>
  );
}
