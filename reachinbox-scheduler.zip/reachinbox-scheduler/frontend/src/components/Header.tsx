import { useAuth } from '../hooks/useAuth';
import { Button } from './ui/Button';
import { SlackConnect } from './SlackConnect';

export function Header() {
  const { user, logout } = useAuth();
  if (!user) return null;
  return (
    <header className="border-b border-line bg-white">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <div className="text-lg font-bold tracking-tight">
          Reach<span className="text-brand">Inbox</span> Scheduler
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <SlackConnect />
          <a href="/admin/queues" target="_blank" rel="noreferrer" className="text-sm font-medium text-muted hover:text-ink">
            Queue dashboard
          </a>
          <div className="flex items-center gap-3 border-l border-line pl-3">
            {user.avatar ? (
              <img src={user.avatar} alt="" referrerPolicy="no-referrer" className="h-9 w-9 rounded-full" />
            ) : (
              <div className="grid h-9 w-9 place-items-center rounded-full bg-brand text-sm font-bold text-white">
                {user.name[0]}
              </div>
            )}
            <div className="leading-tight">
              <div className="text-sm font-semibold">{user.name}</div>
              <div className="text-xs text-muted">{user.email}</div>
            </div>
            <Button variant="secondary" onClick={logout}>
              Log out
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
