import { formatDate } from '../lib';
import type { EmailItem, Tab } from '../types';
import { StatusBadge } from './ui/Badge';
import { Column, DataTable } from './ui/DataTable';

interface Props {
  tab: Tab;
  rows: EmailItem[];
  loading: boolean;
  error: string | null;
  searching: boolean;
}

export function EmailsTable({ tab, rows, loading, error, searching }: Props) {
  const timeColumn: Column<EmailItem> =
    tab === 'scheduled'
      ? { header: 'Scheduled time', render: (r) => formatDate(r.scheduledAt) }
      : { header: 'Sent time', render: (r) => formatDate(r.sentAt) };

  const columns: Column<EmailItem>[] = [
    { header: 'Email', render: (r) => <span className="font-medium">{r.recipient}</span> },
    { header: 'Subject', render: (r) => <span className="line-clamp-1 max-w-xs">{r.subject}</span> },
    timeColumn,
    {
      header: 'Status',
      render: (r) => (
        <span className="flex items-center gap-2">
          <StatusBadge status={r.status} />
          {r.previewUrl && (
            <a href={r.previewUrl} target="_blank" rel="noreferrer" className="text-xs text-brand hover:underline">
              Preview
            </a>
          )}
          {r.status === 'failed' && r.error && <span className="max-w-48 truncate text-xs text-bad" title={r.error}>{r.error}</span>}
        </span>
      ),
    },
  ];

  const empty = searching
    ? { title: 'No matches', hint: 'Try a different recipient, subject or word from the body.' }
    : tab === 'scheduled'
      ? { title: 'Nothing scheduled', hint: 'Select Compose new email to schedule your first batch.' }
      : { title: 'Nothing sent yet', hint: 'Emails appear here as soon as they are delivered.' };

  return <DataTable columns={columns} rows={rows} rowKey={(r) => r.id} loading={loading} error={error} empty={empty} />;
}
