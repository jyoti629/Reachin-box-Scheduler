import { ChangeEvent, FormEvent, useState } from 'react';
import { api } from '../api';
import { extractEmails, toIso } from '../lib';
import { Button } from './ui/Button';
import { Input, Textarea } from './ui/Field';
import { Modal } from './ui/Modal';
import { useToast } from './ui/Toast';

export function ComposeModal({ onClose, onScheduled }: { onClose: () => void; onScheduled: () => void }) {
  const toast = useToast();
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [recipients, setRecipients] = useState<string[]>([]);
  const [fileName, setFileName] = useState('');
  const [startTime, setStartTime] = useState('');
  const [delay, setDelay] = useState('2');
  const [hourly, setHourly] = useState('100');
  const [submitting, setSubmitting] = useState(false);

  async function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setRecipients(extractEmails(await file.text()));
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!recipients.length) return toast('error', 'Upload a CSV or text file that contains email addresses.');
    setSubmitting(true);
    try {
      const res = await api.schedule({
        subject,
        body,
        recipients,
        startTime: toIso(startTime),
        delaySeconds: Number(delay) || 0,
        hourlyLimit: hourly ? Number(hourly) : undefined,
      });
      toast(
        'success',
        `Scheduled ${res.scheduled} email${res.scheduled === 1 ? '' : 's'}` +
          (res.hourWindows > 1 ? ` across ${res.hourWindows} hourly windows (hourly limit applied).` : '.'),
      );
      onScheduled();
      onClose();
    } catch (err) {
      toast('error', (err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Compose new email" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <Input label="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} required maxLength={300} />
        <Textarea label="Body" value={body} onChange={(e) => setBody(e.target.value)} required />

        <div>
          <span className="mb-1 block text-sm font-medium">Leads file</span>
          <input
            type="file"
            accept=".csv,.txt,text/csv,text/plain"
            onChange={onFile}
            className="block w-full text-sm file:mr-3 file:rounded-md file:border file:border-line file:bg-white file:px-3 file:py-2 file:text-sm file:font-semibold hover:file:bg-canvas"
          />
          {fileName && (
            <p className="mt-1 text-sm" role="status">
              {recipients.length ? (
                <span className="font-semibold text-ok">{recipients.length} email addresses detected</span>
              ) : (
                <span className="text-bad">No email addresses found in {fileName}</span>
              )}
            </p>
          )}
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <Input label="Start time" type="datetime-local" value={startTime} onChange={(e) => setStartTime(e.target.value)} hint="Empty = now" />
          <Input label="Delay between emails (s)" type="number" min={0} value={delay} onChange={(e) => setDelay(e.target.value)} />
          <Input label="Hourly limit" type="number" min={1} value={hourly} onChange={(e) => setHourly(e.target.value)} hint="Per sender" />
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={submitting}>
            Schedule
          </Button>
        </div>
      </form>
    </Modal>
  );
}
