import type { EmailList, ScheduleRequest, ScheduleResponse, SlackStatus, Stats, Tab, User } from './types';

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    ...init,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new ApiError(res.status, body.error ?? res.statusText);
  }
  return res.json();
}

export const api = {
  me: () => request<User>('/api/auth/me'),
  authConfig: () => request<{ devLogin: boolean; googleConfigured: boolean }>('/api/auth/config'),
  logout: () => request<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),
  emails: (tab: Tab, q: string) =>
    request<EmailList>(`/api/emails?status=${tab}&limit=100${q ? `&q=${encodeURIComponent(q)}` : ''}`),
  schedule: (body: ScheduleRequest) =>
    request<ScheduleResponse>('/api/emails/schedule', { method: 'POST', body: JSON.stringify(body) }),
  stats: () => request<Stats>('/api/stats'),
  slackStatus: () => request<SlackStatus>('/api/slack/status'),
  slackTest: () => request<{ ok: boolean }>('/api/slack/test', { method: 'POST' }),
  slackDisconnect: () => request<{ ok: boolean }>('/api/slack', { method: 'DELETE' }),
};
