const fmt = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' });
export const formatDate = (iso: string | null) => (iso ? fmt.format(new Date(iso)) : '—');

const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;

/** Pull unique email addresses out of any CSV / text file. */
export function extractEmails(text: string): string[] {
  return [...new Set((text.match(EMAIL_RE) ?? []).map((e) => e.toLowerCase()))];
}

/** datetime-local value -> ISO string (or undefined = start now). */
export const toIso = (local: string) => (local ? new Date(local).toISOString() : undefined);
