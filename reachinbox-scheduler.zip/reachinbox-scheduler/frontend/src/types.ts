export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string | null;
}

export type EmailStatus = 'scheduled' | 'processing' | 'sent' | 'failed';
export type Tab = 'scheduled' | 'sent';

export interface EmailItem {
  id: string;
  recipient: string;
  subject: string;
  status: EmailStatus;
  scheduledAt: string;
  sentAt: string | null;
  previewUrl: string | null;
  senderEmail: string | null;
  error: string | null;
}

export interface EmailList {
  items: EmailItem[];
  total: number;
  counts: Record<Tab, number>;
}

export interface ScheduleRequest {
  subject: string;
  body: string;
  recipients: string[];
  startTime?: string;
  delaySeconds: number;
  hourlyLimit?: number;
}

export interface ScheduleResponse {
  batchId: string;
  scheduled: number;
  duplicatesRemoved: number;
  firstAt: string | null;
  lastAt: string | null;
  hourWindows: number;
}

export interface SlackStatus {
  connected: boolean;
  channel: string | null;
  team: string | null;
}

export interface Stats {
  queue: { waiting: number; delayed: number; active: number; completed: number; failed: number };
  senders: { id: number; email: string; usedThisHour: number; limit: number }[];
  worker: { concurrency: number; minDelayMs: number };
  windowEndsAt: string;
}
