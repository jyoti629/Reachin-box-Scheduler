import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../api';
import type { EmailList, Tab } from '../types';

/** Loads one tab and refreshes it every few seconds so status changes show up live. */
export function useEmails(tab: Tab, query: string, pollMs = 4000) {
  const [data, setData] = useState<EmailList | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const latest = useRef(0);

  const load = useCallback(
    async (showSpinner: boolean) => {
      const id = ++latest.current;
      if (showSpinner) setLoading(true);
      try {
        const res = await api.emails(tab, query);
        if (id === latest.current) {
          setData(res);
          setError(null);
        }
      } catch (e) {
        if (id === latest.current) setError((e as Error).message);
      } finally {
        if (id === latest.current) setLoading(false);
      }
    },
    [tab, query],
  );

  useEffect(() => {
    load(true);
    const t = setInterval(() => load(false), pollMs);
    return () => clearInterval(t);
  }, [load, pollMs]);

  return { data, loading, error, refresh: () => load(false) };
}
