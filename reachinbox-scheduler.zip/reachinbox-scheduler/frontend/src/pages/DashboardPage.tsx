import { useEffect, useState } from 'react';
import { ComposeModal } from '../components/ComposeModal';
import { EmailsTable } from '../components/EmailsTable';
import { Header } from '../components/Header';
import { StatsBar } from '../components/StatsBar';
import { Button } from '../components/ui/Button';
import { useEmails } from '../hooks/useEmails';
import type { Tab } from '../types';

const TABS: { id: Tab; label: string }[] = [
  { id: 'scheduled', label: 'Scheduled emails' },
  { id: 'sent', label: 'Sent emails' },
];

export function DashboardPage() {
  const [tab, setTab] = useState<Tab>('scheduled');
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [composing, setComposing] = useState(false);

  // debounce the search box
  useEffect(() => {
    const t = setTimeout(() => setQuery(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  const { data, loading, error, refresh } = useEmails(tab, query);

  return (
    <>
      <Header />
      <main className="mx-auto max-w-6xl px-4 py-6">
        <StatsBar />
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <nav className="flex gap-1 rounded-lg bg-white p-1 shadow-sm" aria-label="Email lists">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                aria-current={tab === t.id}
                className={`rounded-md px-4 py-2 text-sm font-semibold transition-colors ${
                  tab === t.id ? 'bg-brand text-white' : 'text-muted hover:text-ink'
                }`}
              >
                {t.label}
                {data && <span className="ml-2 opacity-70">{data.counts[t.id]}</span>}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search recipient, subject, body"
              aria-label="Search emails"
              className="w-64 rounded-md border border-line bg-white px-3 py-2 text-sm focus:border-brand focus:outline-none"
            />
            <Button onClick={() => setComposing(true)}>Compose new email</Button>
          </div>
        </div>

        <section className="rounded-lg border border-line bg-white shadow-sm">
          <EmailsTable tab={tab} rows={data?.items ?? []} loading={loading} error={error} searching={!!query} />
        </section>
      </main>
      {composing && <ComposeModal onClose={() => setComposing(false)} onScheduled={refresh} />}
    </>
  );
}
