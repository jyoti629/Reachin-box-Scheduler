import { useEffect, useState } from 'react';
import { api } from '../api';
import { Button } from '../components/ui/Button';

type Config = { devLogin: boolean; googleConfigured: boolean };

export function LoginPage() {
  const [cfg, setCfg] = useState<Config | null>(null);
  const [problem, setProblem] = useState<string | null>(null);
  const failed = new URLSearchParams(window.location.search).get('error');

  useEffect(() => {
    api
      .authConfig()
      .then(setCfg)
      .catch((e: Error) =>
        setProblem(
          `The backend is not reachable (${e.message}). Start it with "npm run dev" and check its terminal; "npm run doctor" shows what is missing.`,
        ),
      );
  }, []);

  const googleReady = !!cfg?.googleConfigured;

  return (
    <main className="grid min-h-screen place-items-center px-4">
      <div className="w-full max-w-sm rounded-lg border border-line bg-white p-8 text-center shadow-sm">
        <h1 className="text-2xl font-bold tracking-tight">
          Reach<span className="text-brand">Inbox</span> Scheduler
        </h1>
        <p className="mt-2 text-sm text-muted">Schedule outreach emails and watch them go out on time.</p>

        {failed && <p className="mt-4 text-sm text-bad">Google sign-in failed. Try again.</p>}
        {problem && (
          <p role="alert" className="mt-4 rounded-md bg-bad/10 p-3 text-left text-sm text-bad">
            {problem}
          </p>
        )}
        {cfg && !googleReady && (
          <p role="alert" className="mt-4 rounded-md bg-warn/15 p-3 text-left text-sm text-warn">
            Google sign-in is not configured. Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to backend/.env and restart the
            backend.
          </p>
        )}

        <Button
          className="mt-6 w-full py-2.5"
          disabled={!googleReady}
          onClick={() => (window.location.href = '/api/auth/google')}
        >
          Continue with Google
        </Button>
        {cfg?.devLogin && (
          <Button variant="secondary" className="mt-3 w-full" onClick={() => (window.location.href = '/api/auth/dev')}>
            Dev login (local testing)
          </Button>
        )}
      </div>
    </main>
  );
}
