import { pool } from './db';
import { enqueueMany } from './queue';

/**
 * Boot-time safety net (not a cron: runs once at startup).
 * Re-enqueues rows that should have a job but don't (e.g. Redis was wiped, or the API crashed
 * between the DB insert and the queue add). Existing job ids are ignored by BullMQ, so this
 * can never create duplicates.
 */
export async function reconcile() {
  const { rows } = await pool.query(
    `SELECT id, seq, scheduled_at FROM emails
      WHERE status = 'scheduled'
         OR (status = 'processing' AND claimed_at < now() - interval '5 minutes')
      ORDER BY scheduled_at LIMIT 50000`,
  );
  await enqueueMany(rows.map((r) => ({ emailId: r.id, seq: r.seq, runAt: new Date(r.scheduled_at) })));
  console.log(`[reconcile] ${rows.length} pending email(s) verified in queue`);
}
