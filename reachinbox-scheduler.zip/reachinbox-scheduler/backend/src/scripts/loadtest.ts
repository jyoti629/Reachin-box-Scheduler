/**
 * Behaviour under load: `npm run loadtest -- 1000 5`
 *   arg1 = number of emails (default 1000), arg2 = hourly limit per sender (default: env cap)
 * Schedules them all "due now" for the first user in the DB, then prints how they were spread.
 * Run it while `npm run dev` is running and watch the dashboard / queue dashboard.
 */
import { pool, migrate } from '../db';
import { ensureSenders } from '../mailer';
import { scheduleBatch } from '../scheduleService';

async function main() {
  const count = Number(process.argv[2] ?? 1000);
  const hourly = process.argv[3] ? Number(process.argv[3]) : undefined;
  await migrate();
  await ensureSenders();

  let { rows } = await pool.query('SELECT id FROM users ORDER BY created_at LIMIT 1');
  if (!rows[0]) {
    ({ rows } = await pool.query(
      `INSERT INTO users (google_id, email, name) VALUES ('loadtest-user','loadtest@example.com','Load Test') RETURNING id`,
    ));
    console.log('No users yet: created a load-test user. Sign in with Google to see your own emails.');
  }

  const recipients = Array.from({ length: count }, (_, i) => `load${String(i + 1).padStart(5, '0')}@example.test`);
  const t0 = Date.now();
  const r = await scheduleBatch(rows[0].id, {
    subject: `Load test (${count} emails)`,
    body: 'Hello from the load test.',
    recipients,
    delaySeconds: 0,
    hourlyLimit: hourly,
  });
  console.log(`\nScheduled ${r.scheduled} emails in ${Date.now() - t0} ms across ${r.hourWindows} hour window(s).`);
  console.log(`First send: ${r.firstAt?.toISOString()}  Last send: ${r.lastAt?.toISOString()}\n`);

  const dist = await pool.query(
    `SELECT date_trunc('hour', scheduled_at) AS hour, count(*)::int AS n
       FROM emails WHERE batch_id = $1 GROUP BY 1 ORDER BY 1 LIMIT 8`,
    [r.batchId],
  );
  console.log('Emails per hour window (first 8):');
  for (const d of dist.rows) console.log(`  ${new Date(d.hour).toISOString()}  ${d.n}`);
  process.exit(0);
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
