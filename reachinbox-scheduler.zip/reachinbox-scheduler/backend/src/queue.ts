import { Queue } from 'bullmq';
import { newBullConnection } from './redis';

export const QUEUE_NAME = 'email-jobs';

export interface EmailJobData {
  emailId: string;
  seq: number; // position inside the batch; used to keep order when rescheduling
}

export const emailQueue = new Queue<EmailJobData>(QUEUE_NAME, {
  connection: newBullConnection(),
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 },
    removeOnComplete: { age: 3600, count: 1000 },
    removeOnFail: { age: 86400 },
  },
});

export interface JobSpec {
  emailId: string;
  seq: number;
  runAt: Date;
}

/**
 * jobId === emailId => BullMQ ignores a second add() with the same id.
 * That is the first layer of idempotency (the second is the DB claim in the worker).
 */
export async function enqueueMany(specs: JobSpec[]) {
  const CHUNK = 1000;
  for (let i = 0; i < specs.length; i += CHUNK) {
    const now = Date.now();
    await emailQueue.addBulk(
      specs.slice(i, i + CHUNK).map((s) => ({
        name: 'send',
        data: { emailId: s.emailId, seq: s.seq },
        opts: { jobId: s.emailId, delay: Math.max(0, s.runAt.getTime() - now) },
      })),
    );
  }
}
