import { Router } from 'express';
import { requireAuth, wrap } from '../auth';
import { config } from '../config';
import { listSenders } from '../mailer';
import { emailQueue } from '../queue';
import { usageThisHour } from '../rateLimiter';

const router = Router();

/** Live numbers for the dashboard: queue depth, per-sender usage this hour, worker settings. */
router.get(
  '/',
  requireAuth,
  wrap(async (_req, res) => {
    const senders = await listSenders();
    const [queue, used] = await Promise.all([
      emailQueue.getJobCounts('waiting', 'delayed', 'active', 'completed', 'failed'),
      usageThisHour(senders.map((s) => s.id)),
    ]);
    res.json({
      queue,
      senders: senders.map((s) => ({
        id: s.id,
        email: s.email,
        usedThisHour: used[s.id] ?? 0,
        limit: config.rate.maxPerHourPerSender,
      })),
      worker: { concurrency: config.worker.concurrency, minDelayMs: config.worker.minDelayMs },
      windowEndsAt: new Date((Math.floor(Date.now() / 3_600_000) + 1) * 3_600_000).toISOString(),
    });
  }),
);

export default router;
