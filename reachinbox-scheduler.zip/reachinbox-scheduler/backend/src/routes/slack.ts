import { Router } from 'express';
import jwt from 'jsonwebtoken';
import { AuthedRequest, requireAuth, wrap } from '../auth';
import { config } from '../config';
import { pool } from '../db';
import { postToSlack } from '../slack';

const router = Router();
const redirectUri = `${config.backendUrl}/api/slack/callback`;

// Step 1: send the signed-in user to Slack's authorize page.
router.get('/install', requireAuth, (req, res) => {
  if (!config.slack.clientId) return res.status(500).send('SLACK_CLIENT_ID is not configured');
  const state = jwt.sign({ uid: (req as AuthedRequest).userId, purpose: 'slack' }, config.jwtSecret, { expiresIn: '10m' });
  const url = new URL('https://slack.com/oauth/v2/authorize');
  url.searchParams.set('client_id', config.slack.clientId);
  url.searchParams.set('scope', 'incoming-webhook');
  url.searchParams.set('redirect_uri', redirectUri);
  url.searchParams.set('state', state);
  res.redirect(url.toString());
});

// Step 2: Slack redirects back with ?code. Exchange it and store the webhook for this user.
router.get(
  '/callback',
  wrap(async (req, res) => {
    const { code, state, error } = req.query as Record<string, string | undefined>;
    if (error || !code || !state) return res.redirect(`${config.frontendUrl}/?slack=error`);
    let uid: string;
    try {
      const p = jwt.verify(state, config.jwtSecret) as { uid: string; purpose: string };
      if (p.purpose !== 'slack') throw new Error('bad state');
      uid = p.uid;
    } catch {
      return res.redirect(`${config.frontendUrl}/?slack=error`);
    }
    const r = await fetch('https://slack.com/api/oauth.v2.access', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: config.slack.clientId,
        client_secret: config.slack.clientSecret,
        code,
        redirect_uri: redirectUri,
      }),
    });
    const data: any = await r.json();
    if (!data.ok || !data.incoming_webhook?.url) return res.redirect(`${config.frontendUrl}/?slack=error`);
    await pool.query(
      `INSERT INTO slack_connections (user_id, webhook_url, channel, team_name) VALUES ($1,$2,$3,$4)
       ON CONFLICT (user_id) DO UPDATE SET webhook_url = EXCLUDED.webhook_url, channel = EXCLUDED.channel,
         team_name = EXCLUDED.team_name, created_at = now()`,
      [uid, data.incoming_webhook.url, data.incoming_webhook.channel ?? null, data.team?.name ?? null],
    );
    res.redirect(`${config.frontendUrl}/?slack=connected`);
  }),
);

router.get(
  '/status',
  requireAuth,
  wrap(async (req, res) => {
    const { rows } = await pool.query('SELECT channel, team_name FROM slack_connections WHERE user_id = $1', [
      (req as AuthedRequest).userId,
    ]);
    res.json({ connected: !!rows[0], channel: rows[0]?.channel ?? null, team: rows[0]?.team_name ?? null });
  }),
);

router.post(
  '/test',
  requireAuth,
  wrap(async (req, res) => {
    const ok = await postToSlack((req as AuthedRequest).userId, ':white_check_mark: ReachInbox scheduler is connected to Slack.');
    res.status(ok ? 200 : 400).json({ ok });
  }),
);

router.delete(
  '/',
  requireAuth,
  wrap(async (req, res) => {
    await pool.query('DELETE FROM slack_connections WHERE user_id = $1', [(req as AuthedRequest).userId]);
    res.json({ ok: true });
  }),
);

export default router;
