import { randomBytes } from 'crypto';
import { Router } from 'express';
import { OAuth2Client } from 'google-auth-library';
import { AuthedRequest, requireAuth, signSession, wrap } from '../auth';
import { config } from '../config';
import { pool } from '../db';

const router = Router();
const client = () =>
  new OAuth2Client(config.google.clientId, config.google.clientSecret, `${config.backendUrl}/api/auth/google/callback`);

const setSession = (res: import('express').Response, userId: string) =>
  res.cookie('token', signSession(userId), {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 7 * 24 * 3600_000,
    secure: config.isProd,
  });

/** Lets the UI know whether to show the local-testing login button. */
router.get('/config', (_req, res) =>
  res.json({
    devLogin: process.env.DEV_LOGIN === 'true',
    googleConfigured: !!(config.google.clientId && config.google.clientSecret),
  }),
);

/** LOCAL TESTING ONLY: DEV_LOGIN=true. Never enable in production. The real flow is /google. */
router.get(
  '/dev',
  wrap(async (_req, res) => {
    if (process.env.DEV_LOGIN !== 'true') return res.status(404).end();
    const { rows } = await pool.query(
      `INSERT INTO users (google_id, email, name, avatar) VALUES ('dev-user','dev@example.com','Dev User',NULL)
       ON CONFLICT (google_id) DO UPDATE SET name = EXCLUDED.name RETURNING id`,
    );
    setSession(res, rows[0].id);
    res.redirect(`${config.frontendUrl}/`);
  }),
);

router.get('/google', (_req, res) => {
  if (!config.google.clientId || !config.google.clientSecret) {
    return res.status(500).json({ error: 'GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET are not set in backend/.env' });
  }
  const state = randomBytes(16).toString('hex');
  res.cookie('oauth_state', state, { httpOnly: true, sameSite: 'lax', maxAge: 10 * 60_000, secure: config.isProd });
  res.redirect(
    client().generateAuthUrl({ scope: ['openid', 'email', 'profile'], prompt: 'select_account', state }),
  );
});

router.get(
  '/google/callback',
  wrap(async (req, res) => {
    const { code, state } = req.query as { code?: string; state?: string };
    if (!code || !state || state !== req.cookies?.oauth_state) {
      return res.redirect(`${config.frontendUrl}/?error=oauth_state`);
    }
    const oauth = client();
    const { tokens } = await oauth.getToken(code);
    const ticket = await oauth.verifyIdToken({ idToken: tokens.id_token!, audience: config.google.clientId });
    const p = ticket.getPayload()!;
    const { rows } = await pool.query(
      `INSERT INTO users (google_id, email, name, avatar) VALUES ($1,$2,$3,$4)
       ON CONFLICT (google_id) DO UPDATE SET email = EXCLUDED.email, name = EXCLUDED.name, avatar = EXCLUDED.avatar
       RETURNING id`,
      [p.sub, p.email, p.name ?? p.email, p.picture ?? null],
    );
    res.clearCookie('oauth_state');
    setSession(res, rows[0].id);
    res.redirect(`${config.frontendUrl}/`);
  }),
);

router.get(
  '/me',
  requireAuth,
  wrap(async (req, res) => {
    const { rows } = await pool.query('SELECT id, name, email, avatar FROM users WHERE id = $1', [
      (req as AuthedRequest).userId,
    ]);
    if (!rows[0]) return res.status(401).json({ error: 'Not signed in' });
    res.json(rows[0]);
  }),
);

router.post('/logout', (_req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

export default router;
