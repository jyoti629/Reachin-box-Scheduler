import { Router } from 'express';
import { z } from 'zod';
import { AuthedRequest, requireAuth, wrap } from '../auth';
import { counts, GROUPS, Group, listEmails, toPublic } from '../emailsRepo';
import { scheduleBatch } from '../scheduleService';
import { searchEmails } from '../search';

const router = Router();
router.use(requireAuth);

const scheduleSchema = z.object({
  subject: z.string().trim().min(1).max(300),
  body: z.string().trim().min(1).max(50_000),
  recipients: z.array(z.string().trim().email()).min(1).max(50_000),
  startTime: z.string().datetime({ offset: true }).optional(),
  delaySeconds: z.number().min(0).max(86_400).default(2),
  hourlyLimit: z.number().int().min(1).max(100_000).optional(),
});

router.post(
  '/schedule',
  wrap(async (req, res) => {
    const parsed = scheduleSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });
    const d = parsed.data;
    const recipients = [...new Set(d.recipients.map((r) => r.toLowerCase()))];
    const result = await scheduleBatch((req as AuthedRequest).userId, {
      subject: d.subject,
      body: d.body,
      recipients,
      startTime: d.startTime ? new Date(d.startTime) : undefined,
      delaySeconds: d.delaySeconds,
      hourlyLimit: d.hourlyLimit,
    });
    res.status(201).json({ ...result, duplicatesRemoved: d.recipients.length - recipients.length });
  }),
);

router.get(
  '/',
  wrap(async (req, res) => {
    const userId = (req as AuthedRequest).userId;
    const group: Group = req.query.status === 'sent' ? 'sent' : 'scheduled';
    const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 200);
    const offset = Math.max(Number(req.query.offset) || 0, 0);
    const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';

    let result: { items: any[]; total: number };
    if (q) {
      try {
        result = await searchEmails(userId, q, [...GROUPS[group]], offset, limit, group === 'sent' ? 'sentAt' : 'scheduledAt');
      } catch {
        result = await listEmails(userId, group, limit, offset, q); // Elasticsearch down -> SQL fallback
      }
    } else {
      result = await listEmails(userId, group, limit, offset);
    }
    res.json({ items: result.items.map(toPublic), total: result.total, counts: await counts(userId) });
  }),
);

export default router;
