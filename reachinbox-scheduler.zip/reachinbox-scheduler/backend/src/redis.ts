import IORedis from 'ioredis';
import { config } from './config';

/** Regular connection (rate-limit counters, etc). BullMQ gets its own connections. */
export const redis = new IORedis(config.redisUrl);

/** BullMQ needs maxRetriesPerRequest=null for blocking commands. */
export const newBullConnection = () => new IORedis(config.redisUrl, { maxRetriesPerRequest: null });
