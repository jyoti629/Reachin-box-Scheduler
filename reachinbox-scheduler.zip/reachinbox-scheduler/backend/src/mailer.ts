import nodemailer, { Transporter } from 'nodemailer';
import { config } from './config';
import { pool } from './db';

export interface Sender {
  id: number;
  email: string;
  smtp_user: string;
  smtp_pass: string;
  host: string;
  port: number;
}

/** Make sure we have `SENDER_COUNT` Ethereal sender accounts in the DB. */
export async function ensureSenders() {
  if (process.env.ETHEREAL_ACCOUNTS) {
    try {
      const accounts = JSON.parse(process.env.ETHEREAL_ACCOUNTS) as { user: string; pass: string }[];
      for (const a of accounts) {
        await pool.query(
          `INSERT INTO senders (email, smtp_user, smtp_pass, host, port)
           VALUES ($1,$1,$2,'smtp.ethereal.email',587) ON CONFLICT (email) DO NOTHING`,
          [a.user, a.pass],
        );
      }
    } catch (e) {
      console.warn('[mailer] ETHEREAL_ACCOUNTS is not valid JSON:', (e as Error).message);
    }
  }
  let { rows } = await pool.query('SELECT count(*)::int AS c FROM senders');
  let have = rows[0].c as number;
  while (have < config.senderCount) {
    try {
      const acc = await nodemailer.createTestAccount();
      await pool.query(
        `INSERT INTO senders (email, smtp_user, smtp_pass, host, port) VALUES ($1,$2,$3,$4,$5)
         ON CONFLICT (email) DO NOTHING`,
        [acc.user, acc.user, acc.pass, acc.smtp.host, acc.smtp.port],
      );
      have++;
    } catch (e) {
      console.warn('[mailer] could not create Ethereal account (no internet?):', (e as Error).message);
      break;
    }
  }
  console.log(`[mailer] ${have} sender(s) ready`);
}

export async function listSenders(): Promise<Sender[]> {
  const { rows } = await pool.query('SELECT * FROM senders ORDER BY id');
  return rows;
}

export async function getSender(id: number): Promise<Sender> {
  const { rows } = await pool.query('SELECT * FROM senders WHERE id = $1', [id]);
  if (!rows[0]) throw new Error(`sender ${id} not found`);
  return rows[0];
}

const transports = new Map<number, Transporter>();
function transportFor(s: Sender) {
  let t = transports.get(s.id);
  if (!t) {
    t = nodemailer.createTransport({
      host: s.host,
      port: s.port,
      secure: false,
      auth: { user: s.smtp_user, pass: s.smtp_pass },
    });
    transports.set(s.id, t);
  }
  return t;
}

export async function sendMail(sender: Sender, email: { id: string; recipient: string; subject: string; body: string }) {
  const info = await transportFor(sender).sendMail({
    from: `"ReachInbox Demo" <${sender.email}>`,
    to: email.recipient,
    subject: email.subject,
    text: email.body,
    html: email.body.replace(/\n/g, '<br>'),
    messageId: `<${email.id}@scheduler.local>`, // deterministic: a duplicate send is detectable
  });
  return { previewUrl: (nodemailer.getTestMessageUrl(info) || null) as string | null };
}
