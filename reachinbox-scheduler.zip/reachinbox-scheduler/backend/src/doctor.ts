/** `npm run doctor`: checks everything the app needs and says exactly what to fix. */
import IORedis from 'ioredis';
import { Pool } from 'pg';
import { config } from './config';

let failures = 0;
const ok = (m: string) => console.log(`  ✔ ${m}`);
const warn = (m: string) => console.log(`  ! ${m}`);
const bad = (m: string, fix: string) => {
  failures++;
  console.log(`  ✘ ${m}\n      fix: ${fix}`);
};
const withTimeout = <T>(p: Promise<T>, ms = 5000) =>
  Promise.race([p, new Promise<T>((_, rej) => setTimeout(() => rej(new Error(`timed out after ${ms / 1000}s`)), ms))]);

async function main() {
  console.log('\nReachInbox Scheduler: environment check\n');

  console.log('Config (backend/.env)');
  config.google.clientId && config.google.clientSecret
    ? ok('Google OAuth credentials are set')
    : process.env.DEV_LOGIN === 'true'
      ? warn('Google credentials missing: only the local dev login will work')
      : bad('GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET missing', 'add them to backend/.env (or set DEV_LOGIN=true for local testing), then restart');
  config.jwtSecret === 'dev-secret-change-me' ? warn('JWT_SECRET is the default; set a long random value') : ok('JWT_SECRET is set');
  config.slack.clientId ? ok('Slack credentials are set') : warn('SLACK_CLIENT_ID not set: "Connect Slack" will not work yet');
  process.env.DEV_LOGIN === 'true' && warn('DEV_LOGIN=true (local testing only, never in production)');

  console.log('\nPostgreSQL');
  const pool = new Pool({ connectionString: config.databaseUrl, connectionTimeoutMillis: 5000 });
  try {
    const r = await withTimeout(pool.query('SHOW server_version_num'));
    const v = Number(r.rows[0].server_version_num);
    v >= 130000 ? ok(`connected (v${Math.floor(v / 10000)})`) : bad(`Postgres ${Math.floor(v / 10000)} is too old (need 13+)`, 'use Postgres 13 or newer');
  } catch (e) {
    bad(`cannot connect: ${(e as Error).message}`, 'start Postgres (docker compose up -d) or set DATABASE_URL to a hosted DB such as Neon');
  }
  await pool.end().catch(() => {});

  console.log('\nRedis');
  const redis = new IORedis(config.redisUrl, { maxRetriesPerRequest: 1, retryStrategy: () => null, lazyConnect: true });
  redis.on('error', () => {});
  try {
    await withTimeout(redis.connect());
    const info = await withTimeout(redis.info('server'));
    const ver = /redis_version:(\S+)/.exec(info)?.[1] ?? 'unknown';
    Number(ver.split('.')[0]) >= 5 ? ok(`connected (v${ver})`) : bad(`Redis ${ver} is too old (BullMQ needs 5+, 6.2+ recommended)`, 'use Redis 6.2+ (docker compose, WSL, or Upstash)');
  } catch (e) {
    bad(`cannot connect: ${(e as Error).message}`, 'start Redis (docker compose up -d) or set REDIS_URL to a hosted Redis such as Upstash (rediss://...)');
  }
  redis.disconnect();

  console.log('\nElasticsearch (optional)');
  try {
    const res = await withTimeout(fetch(config.esUrl), 3000);
    res.ok ? ok('reachable') : warn(`responded ${res.status}`);
  } catch {
    warn('not reachable: search will fall back to SQL (everything else works)');
  }

  console.log(failures ? `\n${failures} problem(s) to fix before the app can start.\n` : '\nAll required checks passed. Run: npm run dev\n');
  process.exit(failures ? 1 : 0);
}
main();
