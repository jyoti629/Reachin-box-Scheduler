import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { config } from './config';

export interface AuthedRequest extends Request {
  userId: string;
}

export const signSession = (userId: string) => jwt.sign({ uid: userId }, config.jwtSecret, { expiresIn: '7d' });

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  try {
    const payload = jwt.verify(req.cookies?.token ?? '', config.jwtSecret) as { uid: string };
    (req as AuthedRequest).userId = payload.uid;
    next();
  } catch {
    res.status(401).json({ error: 'Not signed in' });
  }
}

/** Express 4 does not catch async errors; wrap handlers. */
export const wrap =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) =>
    fn(req, res, next).catch(next);
