import { randomUUID } from 'crypto';
import { config } from './config';
import { pool } from './db';
import { EmailDto, toDto } from './emailsRepo';
import { listSenders } from './mailer';
import { enqueueMany } from './queue';
import { indexMany } from './search';

const HOUR = 3_600_000;

export interface ScheduleInput {
  subject: string;
  body: string;
  recipients: string[]; // already de-duplicated
  startTime?: Date;
  delaySeconds: number;
  hourlyLimit?: number;
}

class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

/**
 * Plans, stores and enqueues a batch.
 *
 * Slotting: every email gets a send time that already respects the hourly limit, so 1000+ emails
 * "due now" are spread over the next hour windows up front (order preserved, nothing dropped, no
 * queue churn). Each email goes to the sender that can send it earliest. The worker still enforces
 * the Redis counter as the source of truth (other batches, clock drift, several instances).
 */
export async function scheduleBatch(userId: string, input: ScheduleInput) {
  const senders = await listSenders();
  if (!senders.length) throw new HttpError(503, 'No sender accounts available yet. Restart the backend (needs internet for Ethereal).');

  const limit = Math.min(input.hourlyLimit ?? Infinity, config.rate.maxPerHourPerSender);
  const start = (input.startTime ?? new Date()).getTime();
  const delayMs = input.delaySeconds * 1000;
  const startWindow = Math.floor(start / HOUR);

  // Load already planned/sent emails per (sender, hour) so batches share the same quota.
  const { rows: existing } = await pool.query(
    `SELECT sender_id, floor(extract(epoch FROM COALESCE(sent_at, scheduled_at)) / 3600)::bigint AS w, count(*)::int AS c
       FROM emails
      WHERE sender_id = ANY($1) AND status IN ('scheduled','processing','sent')
        AND COALESCE(sent_at, scheduled_at) >= to_timestamp($2)
      GROUP BY 1, 2`,
    [senders.map((s) => s.id), startWindow * 3600],
  );
  const used = new Map<string, number>(existing.map((r) => [`${r.sender_id}:${r.w}`, r.c as number]));
  const nextAt = senders.map(() => 0);

  const slot = (si: number, desired: number) => {
    let t = Math.max(desired, nextAt[si]);
    let w = Math.floor(t / HOUR);
    while ((used.get(`${senders[si].id}:${w}`) ?? 0) >= limit) {
      w++;
      t = w * HOUR; // next available hour window
    }
    return { t, w };
  };

  const n = senders.length;
  const plan = input.recipients.map((recipient, i) => {
    const desired = start + i * delayMs;
    let best = { si: -1, t: Infinity, w: 0 };
    for (let k = 0; k < n; k++) {
      const si = (i + k) % n; // rotate the tie-break so equal senders alternate
      const s = slot(si, desired);
      if (s.t < best.t) best = { si, ...s };
    }
    const k = `${senders[best.si].id}:${best.w}`;
    used.set(k, (used.get(k) ?? 0) + 1);
    nextAt[best.si] = best.t + delayMs;
    return { seq: i, recipient, senderId: senders[best.si].id, at: new Date(best.t) };
  });

  const batchId = randomUUID();
  const specs: { emailId: string; seq: number; runAt: Date }[] = [];
  const dtos: EmailDto[] = [];

  // 1) Persist first (source of truth).
  for (let i = 0; i < plan.length; i += 1000) {
    const chunk = plan.slice(i, i + 1000);
    const { rows } = await pool.query(
      `INSERT INTO emails (user_id, batch_id, subject, body, hourly_limit, seq, recipient, sender_id, scheduled_at)
       SELECT $1::uuid, $2::uuid, $3, $4, $5::int, t.seq, t.recipient, t.sender_id, t.scheduled_at
         FROM unnest($6::int[], $7::text[], $8::int[], $9::timestamptz[]) AS t(seq, recipient, sender_id, scheduled_at)
       RETURNING *`,
      [
        userId,
        batchId,
        input.subject,
        input.body,
        input.hourlyLimit ?? null,
        chunk.map((c) => c.seq),
        chunk.map((c) => c.recipient),
        chunk.map((c) => c.senderId),
        chunk.map((c) => c.at.toISOString()),
      ],
    );
    for (const r of rows) {
      specs.push({ emailId: r.id, seq: r.seq, runAt: new Date(r.scheduled_at) });
      dtos.push(toDto(r));
    }
  }

  // 2) Enqueue delayed BullMQ jobs (jobId = emailId => idempotent). 3) Index for search.
  await enqueueMany(specs);
  void indexMany(dtos);

  const firstAt = plan[0]?.at ?? null;
  const lastAt = plan[plan.length - 1]?.at ?? null;
  const windows = new Set(plan.map((p) => Math.floor(p.at.getTime() / HOUR))).size;
  return { batchId, scheduled: plan.length, firstAt, lastAt, hourWindows: windows };
}
