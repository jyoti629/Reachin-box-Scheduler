import 'dotenv/config';

const num = (key: string, fallback: number) => {
  const v = Number(process.env[key]);
  return Number.isFinite(v) && process.env[key] !== undefined && process.env[key] !== '' ? v : fallback;
};

export const config = {
  port: num('PORT', 4000),
  backendUrl: process.env.BACKEND_URL ?? 'http://localhost:4000',
  frontendUrl: process.env.FRONTEND_URL ?? 'http://localhost:5173',
  jwtSecret: process.env.JWT_SECRET ?? 'dev-secret-change-me',
  isProd: process.env.NODE_ENV === 'production',
  databaseUrl: process.env.DATABASE_URL ?? 'postgres://postgres:postgres@localhost:5432/scheduler',
  redisUrl: process.env.REDIS_URL ?? 'redis://localhost:6379',
  esUrl: process.env.ELASTICSEARCH_URL ?? 'http://localhost:9200',
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID ?? '',
    clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? '',
  },
  slack: {
    clientId: process.env.SLACK_CLIENT_ID ?? '',
    clientSecret: process.env.SLACK_CLIENT_SECRET ?? '',
  },
  senderCount: num('SENDER_COUNT', 3),
  worker: {
    concurrency: num('WORKER_CONCURRENCY', 5),
    minDelayMs: num('MIN_DELAY_BETWEEN_EMAILS_MS', 2000),
  },
  rate: {
    maxPerHourPerSender: num('MAX_EMAILS_PER_HOUR_PER_SENDER', 100),
  },
  role: (process.env.ROLE ?? 'all') as 'all' | 'api' | 'worker',
};
