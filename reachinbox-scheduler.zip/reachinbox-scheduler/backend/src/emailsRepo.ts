import { pool } from './db';

export const GROUPS = {
  scheduled: ['scheduled', 'processing'],
  sent: ['sent', 'failed'],
} as const;
export type Group = keyof typeof GROUPS;

const SELECT = `SELECT e.*, s.email AS sender_email
                FROM emails e LEFT JOIN senders s ON s.id = e.sender_id`;

export interface EmailDto {
  id: string;
  userId: string;
  recipient: string;
  subject: string;
  body: string;
  status: string;
  scheduledAt: string;
  sentAt: string | null;
  previewUrl: string | null;
  senderEmail: string | null;
  error: string | null;
}

export const toDto = (r: any): EmailDto => ({
  id: r.id,
  userId: r.user_id,
  recipient: r.recipient,
  subject: r.subject,
  body: r.body,
  status: r.status,
  scheduledAt: new Date(r.scheduled_at).toISOString(),
  sentAt: r.sent_at ? new Date(r.sent_at).toISOString() : null,
  previewUrl: r.preview_url,
  senderEmail: r.sender_email,
  error: r.error,
});

/** What the API returns: no body / userId. */
export const toPublic = ({ body, userId, ...rest }: EmailDto) => rest;

export async function getEmail(id: string) {
  const { rows } = await pool.query(`${SELECT} WHERE e.id = $1`, [id]);
  return rows[0] ? toDto(rows[0]) : null;
}

export async function listEmails(userId: string, group: Group, limit: number, offset: number, q?: string) {
  const statuses = [...GROUPS[group]];
  const order = group === 'scheduled' ? 'e.scheduled_at ASC' : 'e.sent_at DESC NULLS LAST, e.scheduled_at DESC';
  const params: unknown[] = [userId, statuses];
  let where = 'e.user_id = $1 AND e.status = ANY($2)';
  if (q) {
    params.push(`%${q}%`);
    where += ` AND (e.recipient ILIKE $3 OR e.subject ILIKE $3 OR e.body ILIKE $3)`;
  }
  const [items, total] = await Promise.all([
    pool.query(`${SELECT} WHERE ${where} ORDER BY ${order} LIMIT ${limit} OFFSET ${offset}`, params),
    pool.query(`SELECT count(*)::int AS c FROM emails e WHERE ${where}`, params),
  ]);
  return { items: items.rows.map(toDto), total: total.rows[0].c as number };
}

export async function counts(userId: string) {
  const { rows } = await pool.query(
    `SELECT
       count(*) FILTER (WHERE status = ANY($2))::int AS scheduled,
       count(*) FILTER (WHERE status = ANY($3))::int AS sent
     FROM emails WHERE user_id = $1`,
    [userId, [...GROUPS.scheduled], [...GROUPS.sent]],
  );
  return rows[0] as { scheduled: number; sent: number };
}
