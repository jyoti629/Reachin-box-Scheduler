import { createBullBoard } from '@bull-board/api';
import { BullMQAdapter } from '@bull-board/api/bullMQAdapter';
import { ExpressAdapter } from '@bull-board/express';
import cookieParser from 'cookie-parser';
import express, { NextFunction, Request, Response } from 'express';
import { requireAuth } from './auth';
import { config } from './config';
import { migrate, pool } from './db';
import { redis } from './redis';
import { ensureSenders } from './mailer';
import { emailQueue } from './queue';
import { reconcile } from './reconcile';
import authRoutes from './routes/auth';
import emailRoutes from './routes/emails';
import slackRoutes from './routes/slack';
import statsRoutes from './routes/stats';
import { initSearch } from './search';
import { startWorker } from './worker';

async function check(name: string, url: string, probe: () => Promise<unknown>) {
  try {
    await Promise.race([probe(), new Promise((_, rej) => setTimeout(() => rej(new Error('timed out after 5s')), 5000))]);
    console.log(`[startup] ${name} OK`);
  } catch (e) {
    console.error(`\n[startup] Cannot reach ${name} at ${url}\n          ${(e as Error).message}`);
    console.error('          Start it (docker compose up -d) or point the env var at a hosted instance.\n');
    process.exit(1);
  }
}

process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));

async function main() {
  await check('PostgreSQL', config.databaseUrl.replace(/:[^:@/]*@/, ':***@'), () => pool.query('SELECT 1'));
  await check('Redis', config.redisUrl, () => redis.ping());
  await migrate();
  await ensureSenders();
  void initSearch(); // background: Elasticsearch is optional and must never block startup

  if (config.role !== 'api') startWorker();
  await reconcile(); // after the worker is up, so overdue jobs are picked up immediately

  if (config.role === 'worker') return;

  const app = express();
  app.use(express.json({ limit: '10mb' }));
  app.use(cookieParser());

  app.get('/api/health', (_req, res) => res.json({ ok: true }));
  app.use('/api/auth', authRoutes);
  app.use('/api/emails', emailRoutes);
  app.use('/api/slack', slackRoutes);
  app.use('/api/stats', statsRoutes);

  // Live BullMQ dashboard (sign in first).
  const board = new ExpressAdapter();
  board.setBasePath('/admin/queues');
  createBullBoard({ queues: [new BullMQAdapter(emailQueue as any) as any], serverAdapter: board });
  app.use('/admin/queues', requireAuth, board.getRouter());

  app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    const status = (err as any).status ?? 500;
    if (status >= 500 && !(err as any).status) console.error(err);
    res.status(status).json({ error: status < 500 ? err.message : (err as any).status ? err.message : 'Something went wrong' });
  });

  app.listen(config.port, () => console.log(`[api] listening on :${config.port}`));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
