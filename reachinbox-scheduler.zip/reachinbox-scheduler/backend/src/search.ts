import { Client } from '@elastic/elasticsearch';
import { config } from './config';
import { pool } from './db';
import { EmailDto, getEmail, toDto } from './emailsRepo';

const es = new Client({ node: config.esUrl, requestTimeout: 3000, maxRetries: 0 });
const INDEX = 'emails';

export async function initSearch() {
  try {
    const exists = await es.indices.exists({ index: INDEX });
    if (!exists) {
      await es.indices.create({
        index: INDEX,
        mappings: {
          properties: {
            userId: { type: 'keyword' },
            recipient: { type: 'text', fields: { keyword: { type: 'keyword' } } },
            subject: { type: 'text' },
            body: { type: 'text' },
            status: { type: 'keyword' },
            scheduledAt: { type: 'date' },
            sentAt: { type: 'date' },
          },
        },
      });
    }
    await reindexAll();
  } catch (e) {
    console.warn('[search] Elasticsearch unavailable, search will fall back to SQL:', (e as Error).message);
  }
}

/** Index/update one email. Never throws: search is secondary to sending. */
export async function indexEmail(id: string) {
  try {
    const dto = await getEmail(id);
    if (dto) await es.index({ index: INDEX, id: dto.id, document: dto });
  } catch (e) {
    console.warn('[search] index failed:', (e as Error).message);
  }
}

export async function indexMany(dtos: EmailDto[]) {
  if (!dtos.length) return;
  try {
    const operations = dtos.flatMap((d) => [{ index: { _index: INDEX, _id: d.id } }, d]);
    await es.bulk({ operations, refresh: false });
  } catch (e) {
    console.warn('[search] bulk index failed:', (e as Error).message);
  }
}

async function reindexAll() {
  const { rows } = await pool.query(
    `SELECT e.*, s.email AS sender_email FROM emails e LEFT JOIN senders s ON s.id = e.sender_id
     ORDER BY e.created_at DESC LIMIT 20000`,
  );
  for (let i = 0; i < rows.length; i += 1000) await indexMany(rows.slice(i, i + 1000).map(toDto));
}

/** Throws if ES is down so the route can fall back to SQL. */
export async function searchEmails(
  userId: string,
  q: string,
  statuses: string[],
  from: number,
  size: number,
  sort: 'scheduledAt' | 'sentAt',
) {
  const r = await es.search<EmailDto>({
    index: INDEX,
    from,
    size,
    sort: [{ [sort]: { order: sort === 'sentAt' ? 'desc' : 'asc', unmapped_type: 'date' } }],
    query: {
      bool: {
        filter: [{ term: { userId } }, { terms: { status: statuses } }],
        must: [{ multi_match: { query: q, fields: ['recipient^2', 'subject', 'body'], fuzziness: 'AUTO' } }],
      },
    },
  });
  const total = typeof r.hits.total === 'number' ? r.hits.total : r.hits.total?.value ?? 0;
  return { items: r.hits.hits.map((h) => h._source!), total };
}
