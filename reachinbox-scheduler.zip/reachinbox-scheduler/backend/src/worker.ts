import { DelayedError, Job, Worker } from 'bullmq';
import { config } from './config';
import { pool } from './db';
import { getEmail } from './emailsRepo';
import { getSender, sendMail } from './mailer';
import { EmailJobData, QUEUE_NAME } from './queue';
import { Acquire, firstNotification, release, tryAcquire } from './rateLimiter';
import { newBullConnection } from './redis';
import { indexEmail } from './search';
import { postToSlack, rateLimitMessage } from './slack';

/** A 'processing' row older than this is assumed to belong to a crashed worker and may be re-claimed. */
const STALE_CLAIM = '5 minutes';

/** Post one Slack alert per sender per hour window, the moment the limit is reached. */
async function alertLimitReached(email: any, limit: number, rl: Acquire) {
  if (!(await firstNotification(email.sender_id, rl.window))) return;
  const sender = await getSender(email.sender_id);
  const { rows } = await pool.query(
    `SELECT count(*)::int AS c FROM emails WHERE sender_id = $1 AND status IN ('scheduled','processing') AND id <> $2`,
    [email.sender_id, email.id],
  );
  const ok = await postToSlack(email.user_id, rateLimitMessage(sender.email, limit, rows[0].c, new Date(rl.nextWindowStart)));
  console.log(`[worker] hourly limit reached for ${sender.email}; slack notified: ${ok}`);
}

async function processor(job: Job<EmailJobData>, token?: string) {
  const { emailId, seq } = job.data;

  // 1) Idempotent claim: only one worker can flip scheduled -> processing.
  const claim = await pool.query(
    `UPDATE emails
        SET status = 'processing', claimed_at = now(), attempts = attempts + 1
      WHERE id = $1
        AND (status = 'scheduled' OR (status = 'processing' AND claimed_at < now() - interval '${STALE_CLAIM}'))
      RETURNING *`,
    [emailId],
  );
  if (!claim.rowCount) return { skipped: true }; // already sent / failed / being handled
  const email = claim.rows[0];

  // 2) Hourly rate limit (per sender, Redis-backed, atomic).
  const limit = Math.min(email.hourly_limit ?? Infinity, config.rate.maxPerHourPerSender);
  const rl = await tryAcquire(email.sender_id, limit);
  if (!rl.allowed) {
    // Not dropped, not failed: push into the next hour window. `seq` offset (ms) keeps batch order.
    const runAt = rl.nextWindowStart + Math.min(seq, 60_000);
    await pool.query(
      `UPDATE emails SET status = 'scheduled', scheduled_at = $2, attempts = attempts - 1 WHERE id = $1`,
      [emailId, new Date(runAt)],
    );
    await indexEmail(emailId);
    await alertLimitReached(email, limit, rl).catch((e) => console.warn('[worker] alert failed:', e.message));
    await job.moveToDelayed(runAt, token);
    throw new DelayedError(); // tells BullMQ the job was moved, not failed
  }

  // 3) Send.
  try {
    const sender = await getSender(email.sender_id);
    const { previewUrl } = await sendMail(sender, email);
    await pool.query(
      `UPDATE emails SET status = 'sent', sent_at = now(), preview_url = $2, error = NULL WHERE id = $1`,
      [emailId, previewUrl],
    );
    await indexEmail(emailId);
    // The send that uses the last slot of the window is "the moment the limit is reached".
    if (rl.count >= limit) await alertLimitReached(email, limit, rl).catch((e) => console.warn('[worker] alert failed:', e.message));
    return { sent: true };
  } catch (err) {
    await release(email.sender_id, rl.window); // failed attempts should not burn quota
    const finalAttempt = job.attemptsMade + 1 >= (job.opts.attempts ?? 1);
    await pool.query(`UPDATE emails SET status = $2, error = $3 WHERE id = $1`, [
      emailId,
      finalAttempt ? 'failed' : 'scheduled',
      (err as Error).message,
    ]);
    await indexEmail(emailId);
    throw err; // BullMQ applies exponential backoff and retries
  }
}

export function startWorker() {
  const worker = new Worker<EmailJobData>(QUEUE_NAME, processor, {
    connection: newBullConnection(),
    concurrency: config.worker.concurrency,
    // Global minimum spacing between sends, shared by every worker instance (Redis-backed).
    limiter: { max: 1, duration: config.worker.minDelayMs },
  });
  worker.on('failed', (job, err) => {
    if (!(err instanceof DelayedError)) console.warn(`[worker] job ${job?.id} failed: ${err.message}`);
  });
  worker.on('error', (err) => console.error('[worker] error', err));
  console.log(
    `[worker] started (concurrency=${config.worker.concurrency}, minDelay=${config.worker.minDelayMs}ms, ` +
      `maxPerHourPerSender=${config.rate.maxPerHourPerSender})`,
  );
  return worker;
}
