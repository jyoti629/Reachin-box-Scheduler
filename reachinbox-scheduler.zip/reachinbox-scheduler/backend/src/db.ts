import { Pool } from 'pg';
import { config } from './config';

export const pool = new Pool({ connectionString: config.databaseUrl });

export async function migrate() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      google_id text UNIQUE NOT NULL,
      email text NOT NULL,
      name text NOT NULL,
      avatar text,
      created_at timestamptz NOT NULL DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS slack_connections (
      user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      webhook_url text NOT NULL,
      channel text,
      team_name text,
      created_at timestamptz NOT NULL DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS senders (
      id serial PRIMARY KEY,
      email text UNIQUE NOT NULL,
      smtp_user text NOT NULL,
      smtp_pass text NOT NULL,
      host text NOT NULL,
      port int NOT NULL
    );
    CREATE TABLE IF NOT EXISTS emails (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      batch_id uuid NOT NULL,
      seq int NOT NULL,
      recipient text NOT NULL,
      subject text NOT NULL,
      body text NOT NULL,
      sender_id int REFERENCES senders(id),
      hourly_limit int,
      scheduled_at timestamptz NOT NULL,
      sent_at timestamptz,
      status text NOT NULL DEFAULT 'scheduled',
      attempts int NOT NULL DEFAULT 0,
      preview_url text,
      error text,
      claimed_at timestamptz,
      created_at timestamptz NOT NULL DEFAULT now()
    );
    CREATE INDEX IF NOT EXISTS emails_user_status_idx ON emails (user_id, status, scheduled_at);
  `);
}
