import { redis } from './redis';

const HOUR_MS = 3_600_000;

/**
 * Atomic fixed-window counter per (sender, hour window), one Lua script in Redis,
 * so it is safe across any number of workers/instances.
 * Returns the new count when a slot was taken, or -1 if the limit is already reached
 * (the increment is rolled back in that case).
 */
const ACQUIRE = `
local c = redis.call('INCR', KEYS[1])
if c == 1 then redis.call('EXPIRE', KEYS[1], ARGV[2]) end
if c > tonumber(ARGV[1]) then
  redis.call('DECR', KEYS[1])
  return -1
end
return c
`;

export interface Acquire {
  allowed: boolean;
  count: number; // sends used in this window after this acquire
  window: number;
  nextWindowStart: number; // epoch ms
}

const key = (senderId: number, window: number) => `rl:${senderId}:${window}`;

export async function tryAcquire(senderId: number, limit: number, now = Date.now()): Promise<Acquire> {
  const window = Math.floor(now / HOUR_MS);
  const n = Number(await redis.eval(ACQUIRE, 1, key(senderId, window), limit, 2 * 3600));
  return { allowed: n > 0, count: n, window, nextWindowStart: (window + 1) * HOUR_MS };
}

/** Give a slot back (used when a send attempt fails so retries don't burn quota twice). */
export async function release(senderId: number, window: number) {
  await redis.decr(key(senderId, window));
}

/** True only for the first caller per (sender, window) -> one Slack alert per window, not one per job. */
export async function firstNotification(senderId: number, window: number) {
  const r = await redis.set(`rl:notified:${senderId}:${window}`, '1', 'EX', 2 * 3600, 'NX');
  return r === 'OK';
}

/** Sends used in the current window, per sender (for the dashboard). */
export async function usageThisHour(senderIds: number[], now = Date.now()) {
  const window = Math.floor(now / HOUR_MS);
  const vals = senderIds.length ? await redis.mget(senderIds.map((id) => key(id, window))) : [];
  return Object.fromEntries(senderIds.map((id, i) => [id, Number(vals[i] ?? 0)])) as Record<number, number>;
}
