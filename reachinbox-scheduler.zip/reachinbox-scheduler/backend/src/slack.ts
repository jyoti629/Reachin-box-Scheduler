import { pool } from './db';

/**
 * Posts to the user's connected Slack incoming webhook.
 * No connection => returns false silently (rate-limit hits must never crash a worker).
 */
export async function postToSlack(userId: string, text: string): Promise<boolean> {
  const { rows } = await pool.query('SELECT webhook_url FROM slack_connections WHERE user_id = $1', [userId]);
  if (!rows[0]) return false;
  try {
    const res = await fetch(rows[0].webhook_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });
    if (res.status === 404 || res.status === 410) {
      // webhook revoked in Slack -> forget it so a re-connect starts clean
      await pool.query('DELETE FROM slack_connections WHERE user_id = $1', [userId]);
      return false;
    }
    return res.ok;
  } catch (e) {
    console.warn('[slack] post failed:', (e as Error).message);
    return false;
  }
}

export function rateLimitMessage(senderEmail: string, limit: number, pending: number, resumeAt: Date) {
  return (
    `:warning: *Hourly limit reached* for sender \`${senderEmail}\` (${limit}/hour).\n` +
    `${pending} more email(s) are queued for the next hour window(s), not dropped. Sending resumes at ${resumeAt.toUTCString()}.`
  );
}
